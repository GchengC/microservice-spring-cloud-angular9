package com.formacionbdi.microservicios.app.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosUsuariosApplicationTests {

    @Test
    void contextLoads() {
    }

}
