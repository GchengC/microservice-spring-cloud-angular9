package com.formacionbdi.microservicios.app.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
