package com.formacionbdi.microservicios.app.respuestas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioRespuestasApplicationTests {

    @Test
    void contextLoads() {
    }

}
