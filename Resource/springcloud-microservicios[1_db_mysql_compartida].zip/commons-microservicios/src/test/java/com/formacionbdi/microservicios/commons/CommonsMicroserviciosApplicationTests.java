package com.formacionbdi.microservicios.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonsMicroserviciosApplicationTests {

    @Test
    void contextLoads() {
    }

}
